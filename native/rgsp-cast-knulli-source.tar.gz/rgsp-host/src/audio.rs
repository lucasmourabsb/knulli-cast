//! KNULLI PipeWire/Pulse monitor capture. No ALSA routing or kernel module.
use std::io::Read;
use std::process::{Child, ChildStdout, Command, Stdio};
use anyhow::{Context, Result};

pub const SAMPLE_RATE: u32 = 48_000;
pub const CHANNELS: u32 = 2;
pub const PERIOD_FRAMES: usize = 240;
const _: () = assert!(PERIOD_FRAMES == moonshine_core::session::stream::audio::FRAME_FRAMES);

// Keep the upstream name so the host pump API remains compatible.
pub struct LoopbackCapture {
    child: Child,
    stdout: ChildStdout,
    bytes: Vec<u8>,
}

impl LoopbackCapture {
    pub fn open(_device: &str) -> Result<Self> {
        let monitor = "alsa_output._sys_devices_platform_soc_soc_03000000_codec_mach_sound_card0.stereo-fallback.monitor";
        let preferences = moonshine_core::stream_preferences::StreamPreferences::from_env();
        let latency = preferences.audio_capture_ms.to_string();
        let fragment = (preferences.audio_capture_ms * SAMPLE_RATE / 1000 * CHANNELS * 2).to_string();
        let mut command = Command::new("/usr/bin/ffmpeg");
        command.env("PULSE_RUNTIME_PATH", "/var/run/pulse")
            .env("PULSE_LATENCY_MSEC", &latency)
            .args(["-hide_banner", "-loglevel", "warning", "-nostdin",
                "-probesize", "32", "-analyzeduration", "1", "-f", "pulse",
                "-fragment_size", &fragment, "-i", monitor,
                "-vn", "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2",
                "-f", "s16le", "-flush_packets", "1", "pipe:1"])
            .stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::inherit());
        #[cfg(target_os = "linux")]
        unsafe {
            use std::os::unix::process::CommandExt;
            command.pre_exec(|| {
                if libc::prctl(libc::PR_SET_PDEATHSIG, libc::SIGTERM) != 0 {
                    return Err(std::io::Error::last_os_error());
                }
                Ok(())
            });
        }
        let mut child = command.spawn().context("starting KNULLI audio monitor")?;
        let stdout = child.stdout.take().expect("piped audio stdout");
        Ok(Self {child, stdout, bytes: Vec::with_capacity(PERIOD_FRAMES * 4)})
    }

    pub fn read(&mut self, samples: &mut [i16]) -> Result<usize> {
        anyhow::ensure!(samples.len() % CHANNELS as usize == 0, "unaligned stereo audio period");
        self.bytes.resize(samples.len() * 2, 0);
        self.stdout.read_exact(&mut self.bytes).context("reading KNULLI monitor PCM")?;
        for (sample, bytes) in samples.iter_mut().zip(self.bytes.chunks_exact(2)) {
            *sample = i16::from_le_bytes([bytes[0], bytes[1]]);
        }
        Ok(samples.len() / CHANNELS as usize)
    }

    pub fn overrun_count(&self) -> u32 { 0 }
}

impl Drop for LoopbackCapture {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}
