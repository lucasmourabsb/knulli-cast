#!/bin/sh
# Hooks run in a subshell with output suppressed and cannot cancel a launch.
# Test that they: are syntactically valid, exit 0 when preconditions are absent,
# exit 0 when preconditions are present, are fast, and actually perform their effects.
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
FAIL=0

# Create a single test directory root and set trap once to clean it all
TEST_ROOT="$TMPDIR/rgsp-test-$$"
mkdir -p "$TEST_ROOT"
trap "rm -rf '$TEST_ROOT'" EXIT

# Test 1: Basic syntax and exit 0 with no preconditions
echo "=== Basic syntax and exit code tests ==="
for h in "$HERE"/../pak/hooks/*/*.sh; do
    [ -f "$h" ] || continue
    name=$(basename "$h")

    sh -n "$h" || { echo "FAIL: $name has a syntax error"; FAIL=1; continue; }

    start=$(date +%s)
    if ! RGSP_RUN_DIR=/nonexistent sh "$h" >/dev/null 2>&1; then
        echo "FAIL: $name exited non-zero with no preconditions"; FAIL=1
    fi
    end=$(date +%s)
    [ $((end - start)) -le 2 ] || { echo "FAIL: $name took too long"; FAIL=1; }

    echo "ok: $name (syntax, exit code, speed)"
done

# Test 2: boot hook removes stale .asoundrc when daemon is NOT running
echo "=== Testing boot hook crash recovery ==="
TESTDIR="$TEST_ROOT/boot"
mkdir -p "$TESTDIR"
export RGSP_RUN_DIR="$TESTDIR"
export USERDATA_PATH="$TESTDIR"
mkdir -p "$TESTDIR"

# Create a stale .asoundrc with our marker
cat > "$TESTDIR/.asoundrc" <<'EOF'
# rgsp-cast: routing playback into the kernel loopback while casting.
pcm.!default {
    type plug
    slave.pcm "hw:Loopback,0,0"
}
EOF

# Run boot hook - should remove the stale .asoundrc
sh "$HERE"/../pak/hooks/boot.d/10-rgsp-aloop.sh >/dev/null 2>&1 || true

# Verify it was removed (daemon not running, so crash recovery should trigger)
if [ -f "$TESTDIR/.asoundrc" ]; then
    echo "FAIL: 10-rgsp-aloop.sh did not remove stale .asoundrc in crash recovery"
    FAIL=1
else
    echo "ok: 10-rgsp-aloop.sh removes stale .asoundrc (crash recovery)"
fi

# Test 3: pre-launch hook writes .asoundrc when daemon IS running
echo "=== Testing pre-launch hook routing ==="
TESTDIR2="$TEST_ROOT/prelaunch"
mkdir -p "$TESTDIR2"
export RGSP_RUN_DIR="$TESTDIR2"
export USERDATA_PATH="$TESTDIR2"
mkdir -p "$TESTDIR2"

# Create a fake daemon PID file (use current shell PID)
echo "$$" > "$TESTDIR2/daemon.pid"

# Run pre-launch hook - should write .asoundrc
sh "$HERE"/../pak/hooks/pre-launch.d/10-rgsp-route.sh >/dev/null 2>&1 || true

# Verify .asoundrc was created with correct content
if ! grep -q 'hw:Loopback,0,0' "$TESTDIR2/.asoundrc" 2>/dev/null; then
    echo "FAIL: 10-rgsp-route.sh did not write .asoundrc routing"
    FAIL=1
else
    echo "ok: 10-rgsp-route.sh writes .asoundrc routing"
fi

# Test 3b: pre-launch hook does not overwrite foreign .asoundrc
echo "=== Testing pre-launch hook does not overwrite foreign config ==="
TESTDIR2b="$TEST_ROOT/prelaunch-foreign"
mkdir -p "$TESTDIR2b"
export RGSP_RUN_DIR="$TESTDIR2b"
export USERDATA_PATH="$TESTDIR2b"
mkdir -p "$TESTDIR2b"

# Create daemon PID
echo "$$" > "$TESTDIR2b/daemon.pid"

# Create a foreign .asoundrc (without our marker)
cat > "$TESTDIR2b/.asoundrc" <<'EOF'
# User's custom Bluetooth routing
pcm.!default {
    type pulse
}
EOF

# Run pre-launch hook - should NOT overwrite this file
sh "$HERE"/../pak/hooks/pre-launch.d/10-rgsp-route.sh >/dev/null 2>&1 || true

# Verify .asoundrc still contains user's config (not ours)
if grep -q 'type pulse' "$TESTDIR2b/.asoundrc" 2>/dev/null; then
    echo "ok: 10-rgsp-route.sh leaves foreign .asoundrc alone"
else
    echo "FAIL: 10-rgsp-route.sh overwrote foreign .asoundrc"
    FAIL=1
fi

# Test 4: pre-sleep hook creates was-casting marker and stops daemon
echo "=== Testing pre-sleep hook ==="
TESTDIR3="$TEST_ROOT/presleep"
mkdir -p "$TESTDIR3"
export RGSP_RUN_DIR="$TESTDIR3"
mkdir -p "$TESTDIR3"

# Create a fake daemon PID file (use a background sleep process)
sleep 100 & FAKE_DAEMON_PID=$!
echo "$FAKE_DAEMON_PID" > "$TESTDIR3/daemon.pid"

# Run pre-sleep hook - should create was-casting marker and stop daemon
sh "$HERE"/../pak/hooks/pre-sleep.d/10-rgsp-stop.sh >/dev/null 2>&1 || true

# Verify was-casting file was created
if [ ! -f "$TESTDIR3/was-casting" ]; then
    echo "FAIL: 10-rgsp-stop.sh did not create was-casting marker"
    FAIL=1
else
    # Verify daemon was actually stopped (kill -0 must fail)
    if kill -0 "$FAKE_DAEMON_PID" 2>/dev/null; then
        echo "FAIL: 10-rgsp-stop.sh did not stop daemon"
        FAIL=1
        kill "$FAKE_DAEMON_PID" 2>/dev/null || true
    else
        echo "ok: 10-rgsp-stop.sh stops daemon and creates was-casting marker"
    fi
fi

# Test 5a: post-resume hook does not start daemon when no was-casting marker
echo "=== Testing post-resume hook (no restart case) ==="
TESTDIR4="$TEST_ROOT/postresume"
mkdir -p "$TESTDIR4"
export RGSP_RUN_DIR="$TESTDIR4"
export RGSP_PAK_DIR="$TESTDIR4/pak"
mkdir -p "$TESTDIR4" "$TESTDIR4/pak" "$TESTDIR4/bin"

# Stub ip command so WiFi loop breaks immediately
cat > "$TESTDIR4/bin/ip" <<'EOF'
#!/bin/sh
echo "    inet 192.168.1.50/24 brd 192.168.1.255 scope global wlan0"
exit 0
EOF
chmod +x "$TESTDIR4/bin/ip"

# Create recording stub for rgsp-host in PAK_DIR
cat > "$TESTDIR4/pak/rgsp-host" <<'EOF'
#!/bin/sh
echo "RGSP_HOST CALLED WITH: $@"
exit 0
EOF
chmod +x "$TESTDIR4/pak/rgsp-host"

# Without was-casting file, hook should exit early and NOT call rgsp-host
export PATH="$TESTDIR4/bin:$PATH"
sh "$HERE"/../pak/hooks/post-resume.d/10-rgsp-resume.sh >/dev/null 2>&1 || true

# Wait for any background process to complete
sleep 0.5

# Verify rgsp-host was NOT called (daemon.log should not exist or be empty)
if [ ! -f "$TESTDIR4/daemon.log" ] || ! grep -q "RGSP_HOST" "$TESTDIR4/daemon.log" 2>/dev/null; then
    echo "ok: 10-rgsp-resume.sh does not start daemon without was-casting marker"
else
    echo "FAIL: 10-rgsp-resume.sh started daemon without was-casting marker"
    FAIL=1
fi

# Test 5b: post-resume hook removes marker and starts daemon when marker present
echo "=== Testing post-resume hook (restart case) ==="
TESTDIR5="$TEST_ROOT/postresume-restart"
mkdir -p "$TESTDIR5"
export RGSP_RUN_DIR="$TESTDIR5"
export RGSP_PAK_DIR="$TESTDIR5/pak"
mkdir -p "$TESTDIR5" "$TESTDIR5/pak" "$TESTDIR5/bin"

# Stub ip command so WiFi loop breaks immediately
cat > "$TESTDIR5/bin/ip" <<'EOF'
#!/bin/sh
echo "    inet 192.168.1.50/24 brd 192.168.1.255 scope global wlan0"
exit 0
EOF
chmod +x "$TESTDIR5/bin/ip"

# Create recording stub for rgsp-host in PAK_DIR
cat > "$TESTDIR5/pak/rgsp-host" <<'EOF'
#!/bin/sh
echo "RGSP_HOST CALLED WITH: $@"
exit 0
EOF
chmod +x "$TESTDIR5/pak/rgsp-host"

# Create mock lib directory for LD_LIBRARY_PATH
mkdir -p "$TESTDIR5/pak/lib/h700"

# Create was-casting marker
touch "$TESTDIR5/was-casting"

# Run hook - should remove marker and start daemon
export PATH="$TESTDIR5/bin:$PATH"
sh "$HERE"/../pak/hooks/post-resume.d/10-rgsp-resume.sh >/dev/null 2>&1 || true

# Give background process a chance to run
sleep 0.5

# Verify was-casting file was removed
if [ -f "$TESTDIR5/was-casting" ]; then
    echo "FAIL: 10-rgsp-resume.sh did not remove was-casting marker"
    FAIL=1
else
    # Verify rgsp-host was called (check daemon.log shows it ran)
    if [ -f "$TESTDIR5/daemon.log" ] && grep -q "RGSP_HOST" "$TESTDIR5/daemon.log" 2>/dev/null; then
        echo "ok: 10-rgsp-resume.sh removes marker and starts daemon"
    else
        echo "FAIL: 10-rgsp-resume.sh did not start daemon"
        FAIL=1
    fi
fi

# Test 6: boot hook leaves live daemon's .asoundrc alone
echo "=== Testing boot hook does not remove live daemon's .asoundrc ==="
TESTDIR6_LIVE="$TEST_ROOT/boot-live"
mkdir -p "$TESTDIR5"
export RGSP_RUN_DIR="$TESTDIR5"
export USERDATA_PATH="$TESTDIR5"

# Create our marker file and a live daemon PID
cat > "$TESTDIR5/.asoundrc" <<'EOF'
# rgsp-cast: routing playback into the kernel loopback while casting.
pcm.!default {
    type plug
    slave.pcm "hw:Loopback,0,0"
}
EOF
echo "$$" > "$TESTDIR5/daemon.pid"

# Run boot hook - should NOT remove the file because daemon is alive
sh "$HERE"/../pak/hooks/boot.d/10-rgsp-aloop.sh >/dev/null 2>&1 || true

# Verify file still exists (daemon is alive, so recovery should not trigger)
if [ ! -f "$TESTDIR5/.asoundrc" ]; then
    echo "FAIL: 10-rgsp-aloop.sh removed .asoundrc while daemon was running"
    FAIL=1
else
    echo "ok: 10-rgsp-aloop.sh leaves live daemon's .asoundrc alone"
fi

# Test 7: boot hook leaves foreign .asoundrc alone
echo "=== Testing boot hook does not remove foreign .asoundrc ==="
TESTDIR6="$TEST_ROOT/boot-foreign"
mkdir -p "$TESTDIR6"
export RGSP_RUN_DIR="$TESTDIR6"
export USERDATA_PATH="$TESTDIR6"

# Create a foreign .asoundrc (no our marker)
cat > "$TESTDIR6/.asoundrc" <<'EOF'
# User's Bluetooth routing
pcm.!default {
    type pulse
}
EOF

# Run boot hook - should NOT remove this file (no our marker)
sh "$HERE"/../pak/hooks/boot.d/10-rgsp-aloop.sh >/dev/null 2>&1 || true

# Verify file still exists
if [ ! -f "$TESTDIR6/.asoundrc" ]; then
    echo "FAIL: 10-rgsp-aloop.sh removed foreign .asoundrc"
    FAIL=1
else
    echo "ok: 10-rgsp-aloop.sh leaves foreign .asoundrc alone"
fi

# Test 8a: boot hook calls insmod when module is absent from lsmod
echo "=== Testing boot hook calls insmod when module is absent ==="
TESTDIR8="$TEST_ROOT/boot-insmod-load"
mkdir -p "$TESTDIR8"
export RGSP_RUN_DIR="$TESTDIR8"
export USERDATA_PATH="$TESTDIR8"
export RGSP_PAK_DIR="$TESTDIR8/pak"
export RGSP_LOG_PATH="$TESTDIR8/logs/rgsp-hooks.log"
mkdir -p "$TESTDIR8/pak" "$TESTDIR8/logs"

# Create dummy module file
touch "$TESTDIR8/pak/snd-aloop.ko"

# Create recording stubs for insmod and lsmod
mkdir -p "$TESTDIR8/bin"
cat > "$TESTDIR8/bin/insmod" <<'EOF'
#!/bin/sh
echo "$@" >> "$RGSP_RUN_DIR/insmod.calls"
exit 0
EOF
chmod +x "$TESTDIR8/bin/insmod"

cat > "$TESTDIR8/bin/lsmod" <<'EOF'
#!/bin/sh
# Report that module is NOT loaded
exit 0
EOF
chmod +x "$TESTDIR8/bin/lsmod"

# Run boot hook - module is absent, so insmod should be called
export PATH="$TESTDIR8/bin:$PATH"
sh "$HERE"/../pak/hooks/boot.d/10-rgsp-aloop.sh >/dev/null 2>&1 || true

# Verify insmod was called with the correct path
if [ -f "$TESTDIR8/insmod.calls" ] && grep -q "snd-aloop.ko" "$TESTDIR8/insmod.calls"; then
    echo "ok: 10-rgsp-aloop.sh calls insmod with module path when absent"
else
    echo "FAIL: 10-rgsp-aloop.sh did not call insmod with module path"
    FAIL=1
fi

# Test 8b: boot hook skips insmod when module is already loaded
echo "=== Testing boot hook skips insmod when module is loaded ==="
TESTDIR9="$TEST_ROOT/boot-insmod-skip"
mkdir -p "$TESTDIR9"
export RGSP_RUN_DIR="$TESTDIR9"
export USERDATA_PATH="$TESTDIR9"
export RGSP_PAK_DIR="$TESTDIR9/pak"
export RGSP_LOG_PATH="$TESTDIR9/logs/rgsp-hooks.log"
mkdir -p "$TESTDIR9/pak" "$TESTDIR9/logs"

# Create dummy module file
touch "$TESTDIR9/pak/snd-aloop.ko"

# Create recording stubs
mkdir -p "$TESTDIR9/bin"
cat > "$TESTDIR9/bin/insmod" <<'EOF'
#!/bin/sh
echo "$@" >> "$RGSP_RUN_DIR/insmod.calls"
exit 0
EOF
chmod +x "$TESTDIR9/bin/insmod"

cat > "$TESTDIR9/bin/lsmod" <<'EOF'
#!/bin/sh
# Report that module IS loaded
echo "snd_aloop 12345 1 - Live 0x00000000"
exit 0
EOF
chmod +x "$TESTDIR9/bin/lsmod"

# Run boot hook - module is loaded, so insmod should NOT be called
export PATH="$TESTDIR9/bin:$PATH"
sh "$HERE"/../pak/hooks/boot.d/10-rgsp-aloop.sh >/dev/null 2>&1 || true

# Verify insmod was NOT called
if [ ! -f "$TESTDIR9/insmod.calls" ] || [ ! -s "$TESTDIR9/insmod.calls" ]; then
    echo "ok: 10-rgsp-aloop.sh skips insmod when module already loaded"
else
    echo "FAIL: 10-rgsp-aloop.sh called insmod even though module was already loaded"
    FAIL=1
fi

# Test 10: Check committed file modes are 100755
echo "=== Checking committed file modes ==="
if git rev-parse --git-dir >/dev/null 2>&1; then
    for hook in pak/hooks/*/*.sh tests/test_hooks.sh; do
        mode=$(git ls-tree HEAD "$hook" 2>/dev/null | awk '{print $1}')
        if [ "$mode" = "100755" ]; then
            echo "ok: $hook has mode 100755"
        elif [ -z "$mode" ]; then
            echo "FAIL: $hook is not committed"
            FAIL=1
        else
            echo "FAIL: $hook has mode $mode, expected 100755"
            FAIL=1
        fi
    done
else
    echo "SKIP: not in git repository, skipping mode check"
fi

echo ""
[ "$FAIL" -eq 0 ] && echo PASS || { echo FAILED; exit 1; }
